## Integration tests for PHP language features of proxies

This folder is used for the caches