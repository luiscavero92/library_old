## Integration tests for PHP language features of proxies

Since proxies are quire complex code, this directory is dedicated
to integration tests that are supposed to cause fatal errors or
failures in general that are hard to handle in traditional
PHPUnit test cases.

You may find a guide on how to write `.phpt` tests on the
[PHP QA website](http://qa.php.net/write-test.php).