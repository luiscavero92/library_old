Container tags
==============

tag1
----

definition_2
~~~~~~~~~~~~

- Class: `Full\Qualified\Class2`
- Public: no
- Synthetic: yes
- Lazy: no
- Shared: yes
- Abstract: no
- Autowired: no
- File: `/path/to/file`
- Factory Service: `factory.service`
- Factory Method: `get`


tag2
----

definition_2
~~~~~~~~~~~~

- Class: `Full\Qualified\Class2`
- Public: no
- Synthetic: yes
- Lazy: no
- Shared: yes
- Abstract: no
- Autowired: no
- File: `/path/to/file`
- Factory Service: `factory.service`
- Factory Method: `get`
