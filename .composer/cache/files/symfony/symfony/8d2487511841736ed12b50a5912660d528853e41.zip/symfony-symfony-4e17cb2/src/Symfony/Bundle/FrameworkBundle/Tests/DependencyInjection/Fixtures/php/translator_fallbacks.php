<?php

$container->loadFromExtension('framework', array(
    'translator' => array(
        'fallbacks' => array('en', 'fr'),
    ),
));
